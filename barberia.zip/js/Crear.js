document.getElementById("Reserva").addEventListener("submit", function(event) {
    // Evitar que se envíe el formulario de forma predeterminada
    event.preventDefault();
    formulario = document.getElementById("Reserva");

    Nombre = document.getElementById("Nombre").value;
    Apellido = document.getElementById("Apellido").value;
    Email = document.getElementById("email").value;
    Telefono = document.getElementById("Telefono").value;
    Fecha = document.getElementById("datePicker").value;
    Hora = document.getElementById("timeSelect").value;
    Servicio = document.getElementById("ServicioOPC").value;
    Barbero = document.getElementById("Persona").value;

    const Reservas = JSON.parse(localStorage.getItem('reservas')) || [];
         
    
    Reservas.push({
        Nombre: Nombre,
        Apellido: Apellido,
        Email: Email,
        Telefono: Telefono,
        Fecha: Fecha,
        Hora: Hora,
        Servicio: Servicio,
        Barbero: Barbero
    });

    localStorage.setItem('reservas', JSON.stringify(Reservas));
    
    console.log("Fueron guardados")
    formulario.reset();
    
    
        // Asignar los datos al modal
        document.getElementById("modalName").textContent = Nombre;
        document.getElementById("modalApellido").textContent = Apellido;
        document.getElementById("modalEmail").textContent = Email;
        document.getElementById("modalTelefono").textContent = Telefono;
        document.getElementById("modalFecha").textContent = Fecha;
        document.getElementById("modalHora").textContent =   Hora;
        document.getElementById("modalServicio").textContent = Servicio;
        document.getElementById("modalBarbero").textContent = Barbero;

        // Mostrar el modal
        $('#modalBody').modal('show');
    



        

});
