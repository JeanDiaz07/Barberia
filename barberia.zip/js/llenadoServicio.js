// script.js

function llenado(Servicio, periodLabel) {
    let times;
    if (Servicio === 'barba') {
        times = [
            "11:00 AM ",
            "12:30 PM ",
            "14:00 PM ",
            "15:30 PM ",
            "17:00 PM ",
            "18:30 PM ",
        ];
    } else if (Servicio === 'pelo') {
        times = [
            "11:00 AM ",
            "12:00 PM ",
            "13:00 PM ",
            "14:00 PM ",
            "15:00 PM ",
            "16:00 PM ",
            "17:00 PM ",
            "18:00 PM ",
            "19:00 PM "
        ];
    } else if (Servicio === 'facial') {
        times = [
            "11:00 AM ",
            "12:30 PM ",
            "14:00 PM ",
            "15:30 PM ",
            "17:00 PM ",
            "18:30 PM ",
        ];
    }

    localStorage.setItem('selectedTimes', JSON.stringify(times));
    localStorage.setItem('selectedPeriod', periodLabel);
    localStorage.setItem('servicioSeleccionado', 'true'); // Set a flag indicating a service has been selected
    localStorage.setItem('selectedService', periodLabel); // Store the selected service type
    window.location.href = 'Reserva.html';
}

function populateTimes() {
    const timeSelect = document.getElementById('timeSelect');
    const times = JSON.parse(localStorage.getItem('selectedTimes')) || [];
    const selectedService = localStorage.getItem('selectedService') || '';

    times.forEach(time => {
        const option = document.createElement('option');
        option.value = time;
        option.textContent = time;
        option.style.color = 'black'; // Corrected syntax
        timeSelect.appendChild(option);
    });

    // Set the value of the ServicioOPC input
    const servicioOPCInput = document.getElementById('ServicioOPC');
    if (servicioOPCInput) {
        servicioOPCInput.value = selectedService;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    if (window.location.pathname.includes('Reserva.html')) {
        populateTimes();
    }
});
