document.addEventListener('DOMContentLoaded', function () {
  const tableBody = document.getElementById('TablaReservas');

  // Obtener todas las claves del localStorage
  const usuarios = JSON.parse(localStorage.getItem('reservas')) || [];

console.log(usuarios);


  // Iterar sobre las claves y agregar filas a la tabla
  for (let i = 0; i < usuarios.length; i++) {
    const usuario = usuarios[i];
   
    const fila = `
    
        <tr>
            
            <td>${i}</td>
            <td>${usuario.Nombre}</td>
            <td>${usuario.Apellido}</td>
            <td>${usuario.Servicio}</td>
            <td>${usuario.Email}</td>
            <td>${usuario.Telefono}</td>
            <td>${usuario.Barbero}</td>
            <td>${usuario.Fecha}</td>
            <td>${usuario.Hora}</td>
            <td> <button onclick="eliminar()">Eliminar </button>    </td> 
            <td>   <button id="Modificar" onclick="editar()">Modificar</button>  </td>

        </tr>
    `;
    tableBody.innerHTML += fila;
}

});