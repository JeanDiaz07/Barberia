// Datos de ejemplo para inicializar (ejecutar solo la primera vez)
// const datos = [
//     { nombre: 'Juan', apellido: 'Pérez', rut: '12345678', email: 'juan@example.com', telefono: '123456789', barbero: 'Carlos', fecha: '2023-01-01', hora: '10:00' },
//     { nombre: 'María', apellido: 'García', rut: '87654321', email: 'maria@example.com', telefono: '987654321', barbero: 'Pedro', fecha: '2023-02-01', hora: '11:00' }
// ];
// localStorage.setItem('tablaDatos', JSON.stringify(datos));

// Función para cargar los datos desde localStorage y mostrarlos en la tabla
/* function cargarDatos() {
    const datosGuardados = JSON.parse(localStorage.getItem('reservas')) || [];
    const tbody = document.querySelector('tablaBody');
    tbody.innerHTML = ''; // Limpiar el cuerpo de la tabla antes de agregar nuevas filas

    datosGuardados.forEach((dato, index) => {
        const fila = document.createElement('tr');

        const celdaNombre = document.createElement('td');
        celdaNombre.textContent = dato.nombre;
        fila.appendChild(celdaNombre);

        const celdaApellido = document.createElement('td');
        celdaApellido.textContent = dato.apellido;
        fila.appendChild(celdaApellido);

        const celdaRut = document.createElement('td');
        celdaRut.textContent = dato.rut;
        fila.appendChild(celdaRut);

        const celdaEmail = document.createElement('td');
        celdaEmail.textContent = dato.email;
        fila.appendChild(celdaEmail);

        const celdaTelefono = document.createElement('td');
        celdaTelefono.textContent = dato.telefono;
        fila.appendChild(celdaTelefono);

        const celdaBarbero = document.createElement('td');
        celdaBarbero.textContent = dato.barbero;
        fila.appendChild(celdaBarbero);

        const celdaFecha = document.createElement('td');
        celdaFecha.textContent = dato.fecha;
        fila.appendChild(celdaFecha);

        const celdaHora = document.createElement('td');
        celdaHora.textContent = dato.hora;
        fila.appendChild(celdaHora);

        const celdaAccion = document.createElement('td');
        const boton = document.createElement('button');
        boton.textContent = 'Editar';
        boton.className = 'btn btn-primary btn-sm';
        boton.setAttribute('data-bs-toggle', 'modal');
        boton.setAttribute('data-bs-target', '#staticBackdrop');
        boton.onclick = () => {
            abrirModalEdicion(index);
        };
        celdaAccion.appendChild(boton);
        fila.appendChild(celdaAccion);

        tbody.appendChild(fila);
    });
}

// Función para abrir el modal con los datos del elemento seleccionado
function abrirModalEdicion(index) {
    const datosGuardados = JSON.parse(localStorage.getItem('tablaBody'));
    const dato = datosGuardados[index];

    document.getElementById('Nombre').value = dato.nombre;
    document.getElementById('Apellido').value = dato.apellido;
    document.getElementById('Rut').value = dato.rut;
    document.getElementById('email').value = dato.email;
    document.getElementById('Telefono').value = dato.telefono;
    document.getElementById('barbero').value = dato.barbero;
    document.getElementById('fecha').value = dato.fecha;
    document.getElementById('hora').value = dato.hora;

    document.getElementById('guardarCambios').onclick = () => {
        guardarCambios(index);
    };
}

// Función para guardar los cambios en localStorage y actualizar la tabla
function guardarCambios(index) {
    const datosGuardados = JSON.parse(localStorage.getItem('tablaBody'));

    datosGuardados[index] = {
        nombre: document.getElementById('Nombre').value,
        apellido: document.getElementById('Apellido').value,
        rut: document.getElementById('Rut').value,
        email: document.getElementById('email').value,
        telefono: document.getElementById('Telefono').value,
        barbero: document.getElementById('barbero').value,
        fecha: document.getElementById('fecha').value,
        hora: document.getElementById('hora').value
    };

    localStorage.setItem('tablaBody', JSON.stringify(datosGuardados));
    cargarDatos();
    // Cerrar el modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('staticBackdrop'));
    modal.hide();
}

// Cargar los datos cuando se cargue la página
document.addEventListener('DOMContentLoaded', cargarDatos);

*/
function editar(index) {



console.log(usuario[i]);

}

